int greenLED = 11;
int yellowLED = 12;
int redLED = 13;
int walkLED = 10;   // Pedestrian LED
int button = 2;     // Pedestrian button

void setup() {
  pinMode(greenLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(redLED, OUTPUT);
  pinMode(walkLED, OUTPUT);
  pinMode(button, INPUT_PULLUP); // Button active LOW
}

void loop() {
  // Normal traffic
  digitalWrite(greenLED, HIGH);
  digitalWrite(walkLED, LOW);

  // Check if button pressed
  if(digitalRead(button) == LOW) {
    // Stop cars
    digitalWrite(greenLED, LOW);

    // Prepare to stop
    digitalWrite(yellowLED, HIGH);
    delay(2000);
    digitalWrite(yellowLED, LOW);

    // Stop cars, allow pedestrians
    digitalWrite(redLED, HIGH);

    // Pedestrian countdown visually
    for(int i = 5; i > 0; i--) {
      digitalWrite(walkLED, HIGH);  // LED ON
      delay(500);
      digitalWrite(walkLED, LOW);   // LED OFF
      delay(500);
    }

    // Reset
    digitalWrite(redLED, LOW);
  }
}